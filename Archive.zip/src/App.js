import React, {useEffect, useRef, useState} from 'react'
import {Area, AreaChart, ResponsiveContainer, XAxis, YAxis} from "recharts";
import {format, parseISO, subDays} from "date-fns";
import THistory from "./components/Trading History/THistory";
import axios from "axios";
import _ from "lodash";
import "./components/Calculator/Calculator.css";
import "./components/Header/graph/graph.css";
import "./components/Connect Wallet Popup/ConnectWPopup.css";
import WalletConnectProvider from "@walletconnect/web3-provider";
import CoinbaseWalletSDK from "@coinbase/wallet-sdk";
import Web3Modal from "web3modal";
import Web3 from "web3";
import {DAI_CONTRACT} from "./AssetContractABI";

const INITIAL_STATE = {
    fetching: false,
    address: "",
    web3: null,
    provider: null,
    connected: false,
    chainId: 1,
    networkId: 1,
    assets: null,
    showModal: false,
    pendingRequest: false,
    result: null
};

const providerOptions = {
    walletConnect: {
        package: WalletConnectProvider,
        options: {
            infuraId: "d92aa38df8c441c5beda785607b37c85",
            chainId: 56,
            darkMode: true,
            rpc: {
                56: "https://bsc-dataseed.binance.org/",
            },
            network: 'BSC',
        },
        display: {
            name: "Mobile",
            logo: "__link_to_ollyswap_logo__",
            description: "Scan qrcode with your mobile wallet",
        },
    },
    trustWallet: {
        package: WalletConnectProvider,
        options: {
            infuraId: "d92aa38df8c441c5beda785607b37c85",
            chainId: 56,
            darkMode: true,
        },
        display: {
            name: "Mobile",
            logo: "__link_to_ollyswap_logo__",
            description: "Scan qrcode with your mobile wallet",
        },
    },
    coinbaseWallet: {
        package: CoinbaseWalletSDK, // Required
        options: {
            appName: "OllySwap", // Required
            infuraId: "d92aa38df8c441c5beda785607b37c85", // Required
            rpc: "", // Optional if `infuraId` is provided; otherwise it's required
            chainId: 56, // Optional. It defaults to 1 if not provided
            darkMode: true, // Optional. Use dark theme, defaults to false
        },
    },
    binanceChainWallet: {
        package: true,
        options: {
            chainId: 56,
            darkMode: true,
        },
    },
    metaMaskWallet: {
        package: true,
        options: {
            chainId: 56,
            darkMode: true,
        },
    }
};

const web3Modal = new Web3Modal({
    network: "mainnet",
    cacheProvider: true,
    providerOptions
})


function App() {
    const API_URL = 'https://api.ollyswap.com/v1';
    const [isMobile, setIsMobile] = useState(true);
    const [agreementOk, setAgreementOk] = useState(false);
    const [currencyList, setCurrencyList] = useState({
        allCurrencies: null,
        currencies: null,
        selectedBlockchain: null,
    });
    const [displayCurrencies, setDisplayCurrencies] = useState(null);
    const [selectedPairs, setSelectedPairs] = useState({
        tradePair: {
            ticker: 'BUSD',
            blockchain: 'BSC'
        },
        basePair: {
            ticker: 'DSF',
            blockchain: 'BSC'
        },
    });

    const [pairType, setPairType] = useState(null)
    const pairTypeRef = useRef(pairType);
    const [walletConnected, setWalletConnected] = useState(false);
    const [network, setNetwork] = useState(null);
    const [tronWeb, setTronWeb] = useState(null);
    const [walletConnection, setWalletConnection] = useState(INITIAL_STATE);

    /************************** BLOCKCHAIN CODE ***************************/

    async function componentDidMount() {
        if (web3Modal.cachedProvider) {
            await onWeb3Connect(null);
        }
    }

    function ConnectToWallet(connector) {
        if(agreementOk) {
            console.log('Connect to', connector);
            connectWallet(connector);
            setWalletConnected(true);
            closeModal();
        }
    }

    const resetApp = async () => {
        const { web3 } = walletConnection;
        if (web3 && web3.currentProvider && web3.currentProvider.close) {
            await web3.currentProvider.close();
        }
        await web3Modal.clearCachedProvider();
        setWalletConnection({ ...INITIAL_STATE });
    };

    const subscribeProvider = async (provider) => {
        if (!provider.on) {
            return;
        }
        provider.on("close", () => resetApp());
        provider.on("accountsChanged", async (accounts) => {
            await setWalletConnection({ ...walletConnection, address: accounts[0] });
            //await getAccountAssets();
        });
        provider.on("chainChanged", async (chainId) => {
            const { web3 } = walletConnection;
            const networkId = await web3.eth.net.getId();
            await setWalletConnection({ ...walletConnection, chainId, networkId });
            //await getAccountAssets();
        });

        provider.on("networkChanged", async (networkId) => {
            const { web3 } = walletConnection;
            const chainId = await web3.eth.chainId();
            await setWalletConnection({ ...walletConnection, chainId, networkId });
            //await getAccountAssets();
        });
    };

    function initWeb3(provider) {
        const web3 = new Web3(provider);
        web3.eth.extend({
            methods: [
                {
                    name: "chainId",
                    call: "eth_chainId",
                    outputFormatter: web3.utils.hexToNumber
                }
            ]
        });
        return web3;
    }

    const onWeb3Connect = async (provider_key = null) => {
        const provider = await web3Modal.connect();
        await subscribeProvider(provider);
        await provider.enable();
        const web3 = initWeb3(provider);
        const accounts = await web3.eth.getAccounts();
        const address = accounts[0];
        const networkId = await web3.eth.net.getId();
        const chainId = await web3.eth.chainId();
        await setWalletConnection({
            ...walletConnection,
            web3,
            provider,
            connected: true,
            address,
            chainId,
            networkId
        });
        //await getAccountAssets();
    };

    function isTronConnected() {
        return !!(window.tronWeb && window.tronWeb.defaultAddress.base58);
    }

    async function connectTronNetwork() {
        //tronWeb.request('')
        return new window.Promise(async function (resolve, reject) {
            if (window.tronLink && window.tronLink.ready) {
                await window.tronLink.request({method: 'tron_requestAccounts'});
                window.tronWeb = window.tronLink.tronWeb;
            }
            let timeLimit = 30 * 1000;
            let currentTime = 0;
            let timer = setInterval( function () {
                if (isTronConnected()) {
                    window.tronWeb.on('addressChanged', async function () {
                        await connectTronNetwork();
                    });
                    clearInterval(timer);
                    setTronWeb(window.tronWeb);
                    setWalletConnection({
                        ...walletConnection,
                        web3: window.tronWeb,
                        address: window.tronWeb.defaultAddress.base58,
                        provider: window.tronWeb,
                        connected: true,
                        chainId: 0,
                        networkId: 0
                    });
                    resolve(true);
                } else {
                    if (currentTime >= timeLimit) {
                        clearInterval(timer);
                        reject(false);
                    }
                    currentTime += 100;
                }
            }, 100);
        });
    }

    async function connectWallet(_provider) {
        if (['walletConnect', 'coinbaseWallet', 'binanceChainWallet', 'metaMaskWallet', 'trustWallet'].indexOf(_provider) !== -1) {
            await onWeb3Connect(_provider);
            setNetwork('BSC');

        }else if (['TokenPocket', 'TronLink'].indexOf(_provider) !== -1) {

            if(window.tronLink && window.tronLink.ready) {
                setTronWeb(window.tronLink);
                await connectTronNetwork();
                setNetwork('TRON');
            }else if(window.tronWeb && window.tronWeb.ready) {
                try {
                    setTronWeb(window.tronWeb);
                    await connectTronNetwork();
                    setNetwork('TRON');
                } catch (e) {
                    console.error(e);
                }
            }else{
                return false;
            }

        }else{
            return false;
        }
    }

    const shortWallet = () => {
        if(!walletConnection.address) {
            return '';
        }else{
            let address = String(walletConnection.address).trim();
            return address.substring(0, 5) + '...' + address.substring(address.length-3, address.length);
        }
    }

    async function fetchWalletAddress() {
        if(network === 'TRON') {
            if(isTronConnected()) {
                return tronWeb.defaultAddress.base58;
            }else{
                return null;
            }
        }else if(network === 'BSC'){
            return walletConnection.address;
        }
    }

    async function initWeb3Transaction(amount, toAddress) {
        const {web3, address, chainId} = walletConnection;

        if (!web3) {
            return null;
        }
        const from = address;
        const to = toAddress;
        const _nonce = await web3.eth.getTransactionCount(from);
        const gas_price = await web3.eth.getGasPrice();
        const gas = 60000;
        const value = web3.utils.toWei(amount.toString(), 'ether');
        const data = "0x";
        const tx = {
            from,
            to,
            _nonce,
            gas_price,
            gas,
            value,
            data
        };

        try {
            setWalletConnection({
                ...walletConnection,
                pendingRequest: true,
            });

            function sendTransaction(_tx) {
                return new Promise((resolve, reject) => {
                    web3.eth
                        .sendTransaction(_tx)
                        .once("transactionHash", (txHash) => resolve(txHash))
                        .catch((err) => reject(err));
                });
            }

            const result = await sendTransaction(tx);
            const formattedResult = {
                action: 'ETH_SEND_TRANSACTION',
                txHash: result,
                from: from,
                to: to,
                value: amount
            };

            setWalletConnection({
                ...walletConnection,
                web3,
                pendingRequest: false,
                result: formattedResult || null
            });

        } catch (e) {
            console.error(e);
            setWalletConnection({ ...walletConnection, web3, pendingRequest: false, result: null });
        }

    }

    async function initWeb3Transfer(ticker, amount, toAddress) {
        const {web3, address, chainId} = walletConnection;

        if (!web3) {
            return null;
        }
        const from = address;
        const to = toAddress;
        const _nonce = await web3.eth.getTransactionCount(from);
        const gas_price = await web3.eth.getGasPrice();
        const gas = 60000;
        const value = web3.utils.toWei(amount.toString(), 'ether');

        try {
            function callTransfer() {
                return new Promise(async(resolve, reject) => {
                    const dai = DAI_CONTRACT[ticker];
                    const contract = new web3.eth.Contract(dai.abi, dai.address);
                    await contract.methods
                        .transfer(to, value)
                        .send({
                            from: address,
                            nonce: _nonce,
                            gas_price: gas_price,
                            gas: gas,
                        }, (err, data) => {
                            if (err) {
                                reject(err)
                            }
                            resolve(data)
                        })
                });
            }

            const result = await callTransfer();
            const formattedResult = {
                action: 'ETH_TOKEN_TRANSFER',
                txHash: result['transactionHash'],
                from: from,
                to: to,
                value: amount
            };
            setWalletConnection({
                ...walletConnection,
                web3,
                pendingRequest: false,
                result: formattedResult || null
            });
        } catch (e) {
            console.error(e);
            setWalletConnection({ ...walletConnection, web3, pendingRequest: false, result: null });
        }
    }

    async function initTronTransaction(amount, toAddress) {
        if(isTronConnected()) {
            try {
                const value = amount * 1e6;
                console.log(toAddress, value, walletConnection.address, 1);
                let tx = await tronWeb.transactionBuilder.sendTrx(toAddress, value);
                console.log(toAddress, value, walletConnection.address, 2);
                let signedTx = await tronWeb.trx.sign(tx);
                console.log(toAddress, value, walletConnection.address, 3);
                let receipt = await tronWeb.trx.sendRawTransaction(signedTx);
                console.log(toAddress, value, walletConnection.address, 4);
                /*let tx = await tronWeb.trx.sendTransaction(toAddress, value).send({
                    from: walletConnection.address,
                    shouldPollResponse: true,
                    feeLimit: 100000000,
                })*/

                console.log(receipt);
                const formattedResult = {
                    action: 'TRON_TRANSACTION',
                    txHash: receipt['txid'],
                    from: walletConnection.address,
                    to: toAddress,
                    value: value,
                    amount: amount
                }
                setWalletConnection({
                    ...walletConnection,
                    pendingRequest: false,
                    result: formattedResult,
                });
            } catch (e) {
                console.error(e);
                setWalletConnection({
                    ...walletConnection,
                    pendingRequest: false,
                    result: null,
                });
            }
        } else {
            setWalletConnection({
                ...walletConnection,
                pendingRequest: false,
                result: null,
            });
        }
    }

    async function initTronTransfer(ticker, amount, toAddress) {
        try {
            const dai = DAI_CONTRACT[ticker];
            let contract = await tronWeb.trx.getContract(dai.address);
            if(!contract) {
                setWalletConnection({
                    ...walletConnection,
                    pendingRequest: false,
                    result: null,
                });
            }else{
                contract = await tronWeb.contract(contract.abi.entrys, dai.address);
                const value = amount * 1e6;
                const tx = await contract.transfer(toAddress, value).send({
                    callValue: 0,
                    shouldPollResponse: true,
                    feeLimit: 100000000,
                    from: walletConnection.address
                });
                console.log(tx);
                const formattedResult = {
                    action: 'TRON_TOKEN_TRANSFER',
                    txHash: tx,
                    from: fetchWalletAddress(),
                    to: toAddress,
                    value: value,
                    amount: amount
                }
                setWalletConnection({
                    ...walletConnection,
                    pendingRequest: false,
                    result: formattedResult,
                });
            }
        } catch (e) {
            console.error(e);
            setWalletConnection({
                ...walletConnection,
                pendingRequest: false,
                result: null,
            });
        }
    }

    async function doTransaction(ticker, amount, toAddress) {
        if(network === 'TRON' && ['TRX', 'USDT'].indexOf(ticker) !== -1) {
            // Tron Transaction
            if(ticker === 'TRX') {
                await initTronTransaction(amount, toAddress);
            }else{
                await initTronTransfer(ticker, amount, toAddress);
            }
        }else if(network === 'BSC' && ['BNB', 'BUSD', 'USDC', 'SHIB'].indexOf(ticker) !== -1) {
            // BSC transaction
            if(ticker === 'BNB') {
                await initWeb3Transaction(amount, toAddress);
            }else{
                await initWeb3Transfer(ticker, amount, toAddress);
            }
        }else{
            return null;
        }
    }


    /************************** BLOCKCHAIN CODE ***************************/



    function closeModal() {
        let modals = document.getElementsByClassName('modal');
        for(let i in modals) {
            i = parseInt(i);
            if(!isNaN(i)) {
                modals[i].classList.remove('show');
                modals[i].style.display = 'none';
            }
        } //modal-backdrop

        let modalBDs = document.getElementsByClassName('modal-backdrop');
        for(let j = modalBDs.length; j--;) {
            j = parseInt(j);
            if(!isNaN(j)) {
                modalBDs[j].parentNode.removeChild(modalBDs[j]);
            }
        }

        let bodyElem = document.body;
        bodyElem.classList.remove('modal-open');
        bodyElem.style.removeProperty('overflow');
    }

    const [graphData, setGraphData] = useState([]);

    const loadGraph = () => {
        let data = []
        for (let num = 30; num >= 0; num--) {
            data.push({
                date: subDays(new Date().getTime(), num).toISOString().substr(0, 10),
                value: 1 + Math.random(),
            });
        }
        setGraphData(data);
    }

    const fetchCurrencies = async () => {
        try {
            let res = await axios.get(API_URL + "/currencies");
            if (res.status === 200) {
                let currencies = res.data.data;
                let allCurrencies = [];
                _.map(currencies, (coins, blockchain) => {
                    _.map(coins, coin => {
                        allCurrencies.push({
                            ...coin,
                            blockchain: blockchain
                        })
                    })
                })

                //console.log('allCurrencies', allCurrencies, currencies);
                setCurrencyList({
                    allCurrencies: allCurrencies,
                    currencies: currencies,
                    selectedBlockchain: null,
                })
                //console.log('currencyList', currencyList);
            }
        } catch (e) {
            console.log(e);
        }
    };

    const loopBlockchains = () => {
        let blockchainList = _.map(currencyList.currencies, (coins, blockchain) => {
            return <button onClick={() => selectBlockchain(blockchain)}
                           className={currencyList.selectedBlockchain === blockchain ? "btn btn-active" : "btn mx-2"} key={blockchain}>{blockchain}</button>
        });
        //console.log(blockchainList);
        return blockchainList;
    }

    const selectBlockchain = (blockchain = null) => {
        let displayItems = []
        //console.log('blockchain', blockchain, currencyList);
        _.map(currencyList.allCurrencies, (currency) => {
            if(blockchain == null || currency.blockchain === blockchain ) {
                //console.log(currency);
                displayItems.push(
                    <div onClick={ () => selectCurrency(currency) } className="token d-flex justify-content-between py-3 ps-2 pe-3 mb-3" key={currency.ticker}>
                        <div className="token-img-token-name d-flex align-items-center">
                            <img
                            src={`./images/${currency.ticker}.png`}
                            width="22px"
                            height="22px"
                            alt=""
                          />
                            <div className="token-name ms-3">
                                <div className="name mb-0">{currency.ticker}</div>
                                <div className="sub-name mb-0">{currency.blockchain}</div>
                            </div>
                        </div>
                        <div className="token-rate align-self-center">
                            ${currency.market_price}
                        </div>
                    </div>
                )
            }
        });
        //console.log(displayItems);
        setDisplayCurrencies(displayItems)
        setCurrencyList({
            ...currencyList,
            selectedBlockchain: blockchain,
        });
    }

    const selectCurrency = async currency => {
        console.log(currency);
        if (pairTypeRef.current === 'TRADE') {
            await setSelectedPairs({
                ...selectedPairs,
                tradePair: currency,
            });

        } else {
            await setSelectedPairs({
                ...selectedPairs,
                basePair: currency,
            });
        }
        await fetchLivePrice(pairTypeRef.current, currency);
        closeModal();
    };

    const [tradePair, setTradePair] = useState({
        trade_blockchain: null,
        trade_currency: null,
        base_blockchain: null,
        base_currency: null,
        trade_amount: 100,
        est_base_amount: 0,
        trade_price: 0,
        base_price: 0,
        trade_liquidity: 0,
        base_liquidity:0,
        sender_address: null,
        recipient_address: '',
    });

    async function fetchLivePrice(pairRef, currency) {
        try {
            let trade_ticker = selectedPairs.tradePair.ticker;
            let trade_blockchain = selectedPairs.tradePair.blockchain;
            let base_ticker = selectedPairs.basePair.ticker;
            let base_blockchain = selectedPairs.basePair.blockchain;
            if(!!pairRef) {
                if(pairRef === 'TRADE'){
                    trade_ticker = currency.ticker;
                    trade_blockchain = currency.blockchain;
                }else{
                    base_ticker = currency.ticker;
                    base_blockchain = currency.blockchain;
                }
            }

            let res = await axios.get(`${API_URL}/last_price?trade_ticker=${trade_ticker}&base_ticker=${base_ticker}`);
            if(res.status === 200) {
                if(res.data.status) {
                    let trade_price = parseFloat((res.data.data.price).toFixed(6));
                    let base_price = parseFloat((1/res.data.data.price).toFixed(6));
                    let est_base_amount = (tradePair.trade_amount * (1-0.002)) * trade_price;
                    setTradePair({
                        ...tradePair,
                        trade_blockchain: trade_blockchain,
                        trade_currency: trade_ticker,
                        base_blockchain: base_blockchain,
                        base_currency: base_ticker,
                        trade_price: trade_price,
                        base_price: base_price,
                        trade_liquidity: res.data.data.trade_liquidity,
                        base_liquidity: res.data.data.base_liquidity,
                        est_base_amount: est_base_amount,
                    });
                }else{
                    // Add Error popup
                }
            }else{
                // Add Error popup
            }
        } catch (e) {
            console.error(e);
        }
    }

    const changeTradePairs = (e) => {
        const {name, value} = e.target;
        if(name === 'trade_amount') {
            let est_base_amount = (value * (1-0.002)) * tradePair.trade_price;
            setTradePair({
                ...tradePair,
                trade_amount: value,
                est_base_amount: est_base_amount,
            });
        }else{
            let trade_amount = (value * (1-0.002)) / tradePair.trade_price;
            setTradePair({
                ...tradePair,
                trade_amount: trade_amount,
                est_base_amount: value,
            });
        }
    };

    const handleStaticChange = (e) => {
        const {name, value} = e.target;
        setTradePair({
            ...tradePair,
            [name]: value,
        });
    }

    const initTrade = async () => {
        try {

            let res = await axios.post(API_URL + '/validate_trade', {
                trade_blockchain: tradePair.trade_blockchain,
                trade_currency: tradePair.trade_currency,
                base_blockchain: tradePair.base_blockchain,
                base_currency: tradePair.base_currency,
                trade_amount: tradePair.trade_amount,
            });

            if(res.status === 200) {
                if(res.data.status) {
                    let res = await axios.post(API_URL + '/trade', {
                        trade_blockchain: tradePair.trade_blockchain,
                        trade_currency: tradePair.trade_currency,
                        base_blockchain: tradePair.base_blockchain,
                        base_currency: tradePair.base_currency,
                        trade_amount: tradePair.trade_amount,
                        sender_address: String(walletConnection.address).trim(),
                        recipient_address: tradePair.recipient_address,
                    });

                    if(res.status === 200) {
                        if(res.data.status) {
                            let hot_wallet = res.data.data.receiving_hot_wallet;
                            await doTransaction(tradePair.trade_currency, tradePair.trade_amount, hot_wallet);
                        }
                    }
                }
            }
        } catch (e) {
            console.error(e);
        }
    };

    useEffect( () => {
        console.log(currencyList.selectedBlockchain);
        if (currencyList.selectedBlockchain === null) {
            fetchCurrencies();
            fetchLivePrice(null, null);
        }
        document.title = 'OllySwap Exchange WebApp';
        loadGraph();

        if(window.tronWeb ) {
            connectTronNetwork();
        }else{
            componentDidMount()
        }

    }, []);




    return (
        <>
            <div
                className=" desk-top-view d-flex flex-md-nowrap flex-wrap ps-md-4 ps-0 "
                style={{ backgroundColor: "rgba(26, 27, 35, 1)" , paddingBottom:"40px" }}
            >
                <div className="col-md-8 col-12 d-flex flex-column">
                    <div className="header">
                        <nav className="navbar ">
                            <div className="container">
                                <a className="navbar-brand" href="/">
                                    <img
                                        src="images/ollygroup.png"
                                        alt=""
                                        width="163px"
                                        height="38px"
                                    />
                                </a>

                                <button
                                    type="button"
                                    className="connect-wallet-btn btn btn-connect d-md-none d-block"
                                    data-bs-toggle="modal"
                                    data-bs-target="#connectModelSM"
                                >
                                    Connect
                                </button>
                                <div
                                    className="modal fade "
                                    id="connectModelSM"
                                    tabIndex="-2"
                                    aria-labelledby="exampleModalLabel"
                                    aria-hidden="true"
                                >
                                    <div className="modal-dialog d-block">
                                        <div className="modal-content sa-modal-content">
                                            {/* <div class="modal-header">
                                 <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                             </div> */}
                                            <div className="modal-body sa-modal-body">
                                                <div className="container sa-container ">
                                                    <div className="sa-bgclr sa-width">
                                                        <div>
                                                            <h1 className=" sa-heading d-flex align-items-baseline justify-content-between">
                                                                Connect Wallet{" "}
                                                                <span>
                                  <button
                                      type="button shodow-none"
                                      className="btn-close pe-3"
                                      data-bs-dismiss="modal"
                                      aria-label="Close"
                                  >
                          <img
                              src="./RightSectionIcons/close-small.png"
                              alt=""
                          />
                        </button>
                                                                    {/* <i className="fa-solid fa-xmark sa-font_Awesome"></i> */}
                                </span>
                                                            </h1>
                                                        </div>
                                                        <div className="sa-inside_bgclr">
                                                            <div className="form-check">
                                                                <input
                                                                    className=" sa-box form-check-input"
                                                                    type="checkbox"
                                                                    value=""
                                                                    id="flexCheckDefault"
                                                                    onClick={() => setAgreementOk(!agreementOk)}
                                                                />
                                                                <label
                                                                    className="form-check-label sa-check"
                                                                    htmlFor="flexCheckDefault"
                                                                >
                                                                    I have read, understand, and agree to{" "}
                                                                    <span className="sa-break">
                                    the <a href="/">Terms of Service.</a>
                                  </span>
                                                                </label>
                                                            </div>
                                                        </div>
                                                        <div className="d-flex sa-inside_bgclr">
                                                            <div className="d-flex" onClick={() => ConnectToWallet('metaMaskWallet')}>
                                                                <img
                                                                    src="images/metamask.png"
                                                                    alt=""
                                                                    className="sa-vector_image"
                                                                    width={40}
                                                                    height={30}
                                                                />
                                                                <div
                                                                    className={
                                                                        agreementOk ? "sa-active_text" : "sa-chain_text"
                                                                    }
                                                                >
                                                                    {" "}
                                                                    Meta Mask
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="d-flex sa-inside_bgclr">
                                                            <div className="d-flex" onClick={() => ConnectToWallet('binanceChainWallet')}>
                                                                <img
                                                                    src="images/Layer.png"
                                                                    alt=""
                                                                    className="sa-vector_image"
                                                                    width={40}
                                                                    height={30}
                                                                />
                                                                <div
                                                                    className={
                                                                        agreementOk ? "sa-active_text" : "sa-chain_text"
                                                                    }
                                                                >
                                                                    {" "}
                                                                    Binance Chain Wallet
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="d-flex sa-inside_bgclr">
                                                            <div className="d-flex" onClick={() => ConnectToWallet('walletConnect')}>
                                                                <img
                                                                    src="images/wconnect.png"
                                                                    alt=""
                                                                    className="sa-vector_image"
                                                                    width={40}
                                                                    height={30}
                                                                />
                                                                <div
                                                                    className={
                                                                        agreementOk ? "sa-active_text" : "sa-chain_text"
                                                                    }
                                                                >
                                                                    {" "}
                                                                    WalletConnect
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="d-flex sa-inside_bgclr">
                                                            <div className="d-flex" onClick={() => ConnectToWallet('metaMaskWallet')}>
                                                                <img
                                                                    src="images/TrustWallet.png"
                                                                    alt=""
                                                                    className="sa-vector_image"
                                                                    width={40}
                                                                    height={30}
                                                                />
                                                                <div
                                                                    className={
                                                                        agreementOk ? "sa-active_text" : "sa-chain_text"
                                                                    }
                                                                >
                                                                    {" "}
                                                                    TrustWallet
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="d-flex sa-inside_bgclr">
                                                            <div className="d-flex" onClick={() => ConnectToWallet('TokenPocket')}>
                                                                <img
                                                                    src="images/TokenPocket.png"
                                                                    alt=""
                                                                    className="sa-vector_image"
                                                                    width={40}
                                                                    height={30}
                                                                />
                                                                <div
                                                                    className={
                                                                        agreementOk ? "sa-active_text" : "sa-chain_text"
                                                                    }
                                                                >
                                                                    {" "}
                                                                    Token Pocket
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="d-flex sa-inside_bgclr">
                                                            <div className="d-flex" onClick={() => ConnectToWallet('TronLink')}>
                                                                <img
                                                                    src="images/TronLink.jpg"
                                                                    alt=""
                                                                    className="sa-vector_image"
                                                                    width={40}
                                                                    height={30}
                                                                />
                                                                <div
                                                                    className={
                                                                        agreementOk ? "sa-active_text" : "sa-chain_text"
                                                                    }
                                                                >
                                                                    {" "}
                                                                    TronLink
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                {/* <button class="btn btn-connect d-md-none d-block " >Connect</button> */}
                            </div>
                        </nav>


                    </div>
                    <div className="graph d-md-block d-none">
                        <div className="graph-container-info-container container  pt-4">
                            <div className="info-container ">
                                <div className="row">
                                    <div className="ic-token-name-refresh-button d-flex align-items-center py-1">
                                        <img
                                            src={`./images/${selectedPairs.tradePair.ticker}.png`}
                                            width="26"
                                            height="26"
                                            alt=""
                                            className="busd-img"
                                        />
                                        <img
                                            src={`./images/${selectedPairs.basePair.ticker}.png`}
                                            width="26"
                                            height="26"
                                            alt=""
                                            className="usdc-img"
                                        />
                                        <div className="token-name text-white px-2">{selectedPairs.tradePair.ticker}/{selectedPairs.basePair.ticker}</div>
                                        <img
                                            src="./RightSectionIcons/rate.png"
                                            width={18}
                                            height={17}
                                            alt=""
                                            className="d-none"
                                        />
                                    </div>
                                    <div className="MainText token-number text-white mb-3">{tradePair.trade_price} {selectedPairs.basePair.ticker}</div>
                                    <div className="token-duration"></div>
                                </div>
                            </div>
                            <div className="duration-wise-data-updated d-flex justify-content-between flex-md-nowrap flex-wrap">
                                <div className="past-24-hours text-white d-none">
                                    <div className="text-green pt-2">
                                        +227.543364 USDC <span className="text-white">Past 24 Hours</span>
                                    </div>
                                </div>
                                {/* <div className="month-week-hours-btns mx-md-0 mx-auto">
          <button className="mwh-btn m-2" style={{backgroundColor:"#3B3C4E", color:"white", borderRadius:"12px",border:"none",fontWeight: "400px"}}>24H</button>
          <button className="mwh-btn2 m-2">1W</button>
          <button className="mwh-btn2 m-2">1M</button>
        </div> */}
                            </div>

                            <ResponsiveContainer width="100%" height={500}>
                                <AreaChart data={graphData}>
                                    <defs>
                                        <linearGradient id="color" x1="0" y1="0" x2="0" y2="1">
                                            <stop
                                                offset="0%"
                                                stopColor="rgba(26, 239, 175, 1)"
                                                stopOpacity={0.7}
                                            />
                                            <stop
                                                offset="75%"
                                                stopColor="rgba(26, 239, 175, 1)"
                                                stopOpacity={0.1}
                                            />
                                        </linearGradient>
                                    </defs>

                                    <Area
                                        dataKey="value"
                                        stroke="rgba(26, 239, 175, 1)"
                                        fill="url(#color)"
                                    />

                                    <XAxis
                                        dataKey="date"
                                        axisLine={false}
                                        tickLine={false}
                                        tickFormatter={(str) => {
                                            const date = parseISO(str);
                                            if (date.getDate() % 7 === 0) {
                                                return format(date, "MMM, d");
                                            }
                                            return "";
                                        }}
                                    />

                                    <YAxis
                                        datakey="value"
                                        axisLine={false}
                                        tickLine={false}
                                        tickCount={8}
                                        tickFormatter={(number) => `$${number.toFixed(2)}`}
                                    />

                                    {/* <Tooltip content={<CustomTooltip />} /> */}

                                    {/* <CartesianGrid opacity={0.1} vertical={false} /> */}
                                </AreaChart>
                            </ResponsiveContainer>
                            <div className="d-md-none d-block">
                                <THistory/>
                            </div>

                        </div>
                    </div>
                </div>
                <div className="col-md-4 col-12" hidden={isMobile}>
                    <div className="graph-container-info-container container  pt-4">
                        <div className="info-container ">
                            <div className="row">
                                <div className="ic-token-name-refresh-button d-flex align-items-center py-3">
                                    <img
                                        src={`./images/${selectedPairs.tradePair.ticker}.png`}
                                        width="26"
                                        height="26"
                                        alt=""
                                        className="busd-img"
                                    />
                                    <img
                                        src={`./images/${selectedPairs.basePair.ticker}.png`}
                                        width="26"
                                        height="26"
                                        alt=""
                                        className="usdc-img"
                                    />
                                    <div className="token-name text-white px-2">{selectedPairs.tradePair.ticker}/{selectedPairs.basePair.ticker}</div>
                                    <img
                                        src="./RightSectionIcons/rate.png"
                                        width={18}
                                        height={17}
                                        alt=""
                                        className="d-none"
                                    />
                                </div>
                                <div className="MainText token-number text-white ">{tradePair.trade_price} {selectedPairs.basePair.ticker}</div>
                                <div className="token-duration "></div>
                            </div>
                        </div>
                        <div className="duration-wise-data-updated d-flex justify-content-between flex-md-nowrap flex-wrap">
                            <div className="past-24-hours text-white d-none">
                                <div className="text-green pt-2">
                                    +227.543364 USDC <span className="text-white">Past 24 Hours</span>
                                </div>
                            </div>
                            {/* <div className="month-week-hours-btns mx-md-0 mx-auto">
          <button className="mwh-btn m-2" style={{backgroundColor:"#3B3C4E", color:"white", borderRadius:"12px",border:"none",fontWeight: "400px"}}>24H</button>
          <button className="mwh-btn2 m-2">1W</button>
          <button className="mwh-btn2 m-2">1M</button>
        </div> */}
                        </div>

                        <ResponsiveContainer width="100%" height={500}>
                            <AreaChart data={graphData}>
                                <defs>
                                    <linearGradient id="color" x1="0" y1="0" x2="0" y2="1">
                                        <stop
                                            offset="0%"
                                            stopColor="rgba(26, 239, 175, 1)"
                                            stopOpacity={0.7}
                                        />
                                        <stop
                                            offset="75%"
                                            stopColor="rgba(26, 239, 175, 1)"
                                            stopOpacity={0.1}
                                        />
                                    </linearGradient>
                                </defs>

                                <Area
                                    dataKey="value"
                                    stroke="rgba(26, 239, 175, 1)"
                                    fill="url(#color)"
                                />

                                <XAxis
                                    dataKey="date"
                                    axisLine={false}
                                    tickLine={false}
                                    tickFormatter={(str) => {
                                        const date = parseISO(str);
                                        if (date.getDate() % 7 === 0) {
                                            return format(date, "MMM, d");
                                        }
                                        return "";
                                    }}
                                />

                                <YAxis
                                    datakey="value"
                                    axisLine={false}
                                    tickLine={false}
                                    tickCount={8}
                                    tickFormatter={(number) => `$${number.toFixed(2)}`}
                                />

                                {/* <Tooltip content={<CustomTooltip />} /> */}

                                {/* <CartesianGrid opacity={0.1} vertical={false} /> */}
                            </AreaChart>
                        </ResponsiveContainer>
                        <div className="d-md-none d-block">
                            <THistory/>
                        </div>

                    </div>
                </div>
                <div className="col-md-4 col-12" hidden={!isMobile}>
                    <div className="col-12">
                        <div className="RightSectionMain d-block ">
                            <div className="container d-md-block d-none">
                                <div className="top  d-flex  justify-content-center ">
                                    {/* <div className="user align-self-center">
              <img src="./RightSectionIcons/Group.png" alt="" />
            </div> */}
                                    <div className="address">
                                        <div className="eth d-flex align-items-center px-3">
                                            <img src="./RightSectionIcons/Group.png" alt=""/>
                                            {
                                                walletConnected &&
                                                <div className="dropdown ms-1">
                                                    <button
                                                        className="btn connect-wallet-btn dropdown-toggle"
                                                        type="button"
                                                        id="dropdownMenuButton1"
                                                        data-bs-toggle="dropdown"
                                                        aria-expanded="false"
                                                    >
                                                        { shortWallet() }
                                                    </button>
                                                    <ul
                                                        className="dropdown-menu p-2"
                                                        aria-labelledby="dropdownMenuButton1"
                                                    >
                                                        <li className="p-0">
                                                            <a className="dropdown-item p-0" href="/">
                                                                Disabled
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            }

                                        </div>
                                    </div>
                                    <div className="address d-flex ms-2">
                                        {
                                            walletConnected &&
                                                <div className="eth d-flex align-items-center px-2">
                                                    <img src="./RightSectionIcons/vector.png" alt=""/>
                                                    <div className="eth-name text-white px-1 ">{network}</div>
                                                </div>

                                        }

                                        <div>
                                            {/* <!-- Button trigger modal --> */}
                                            {/* <button >
              &nbsp;&nbsp; Connect &nbsp; &nbsp;
              </button> */}
                                            <button
                                                type="button"
                                                className="btn connect-wallet-btn "
                                                data-bs-toggle="modal"
                                                data-bs-target="#connectWalletLG"
                                            >
                                                Connect Wallet
                                            </button>
                                            {/* <!-- Modal --> */}
                                            <div
                                                className="modal fade"
                                                id="connectWalletLG"
                                                tabIndex="-2"
                                                aria-labelledby="exampleModalLabel"
                                                aria-hidden="true"
                                            >
                                                <div className="modal-dialog d-md-block d-none">
                                                    <div className="modal-content sa-modal-content">
                                                        {/* <div class="modal-header">
                                 <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                             </div> */}
                                                        <div className="modal-body sa-modal-body">
                                                            <div className="container sa-container ">
                                                                <div className="sa-bgclr sa-width">
                                                                    <div>
                                                                        <h1 className=" sa-heading">
                                                                            Connect Wallet{" "}
                                                                            <span>
                                  <button
                                      type="button"
                                      className="btn-close pe-3 "
                                      data-bs-dismiss="modal"
                                      aria-label="Close"
                                  >
                                    <img
                                        src="./RightSectionIcons/close-small.png"
                                        alt=""
                                    />
                                  </button>
                                                                                {/* <i className="fa-solid fa-xmark sa-font_Awesome"></i> */}
                                </span>
                                                                        </h1>
                                                                    </div>
                                                                    <div className="sa-inside_bgclr">
                                                                        <div className="form-check">
                                                                            <input
                                                                                className=" sa-box form-check-input"
                                                                                type="checkbox"
                                                                                value=""
                                                                                id="flexCheckDefault"
                                                                                onClick={() => setAgreementOk(!agreementOk)}
                                                                            />
                                                                            <label
                                                                                className="form-check-label sa-check"
                                                                                htmlFor="flexCheckDefault"
                                                                            >
                                                                                I have read, understand, and agree
                                                                                to{" "}
                                                                                <span className="sa-break">
                                    the <a href="/">Terms of Service.</a>
                                  </span>
                                                                            </label>
                                                                        </div>
                                                                    </div>
                                                                    <div className="d-flex sa-inside_bgclr">
                                                                        <div className="d-flex" onClick={() => ConnectToWallet('metaMaskWallet')}>
                                                                            <img
                                                                                src="images/metamask.png"
                                                                                alt=""
                                                                                className="sa-vector_image"
                                                                                width={40}
                                                                                height={30}
                                                                            />
                                                                            <h6
                                                                                className={
                                                                                    agreementOk ? "sa-active_text" : "sa-chain_text"
                                                                                }
                                                                            >
                                                                                {" "}
                                                                                Meta Mask
                                                                            </h6>
                                                                        </div>
                                                                    </div>
                                                                    <div className="d-flex sa-inside_bgclr">
                                                                        <div className="d-flex" onClick={() => ConnectToWallet('binanceChainWallet')}>
                                                                            <img
                                                                                src="images/Layer.png"
                                                                                alt=""
                                                                                className="sa-vector_image"
                                                                                width={40}
                                                                                height={30}
                                                                            />
                                                                            <h6
                                                                                className={
                                                                                    agreementOk ? "sa-active_text" : "sa-chain_text"
                                                                                }
                                                                            >
                                                                                {" "}
                                                                                Binance Chain Wallet
                                                                            </h6>
                                                                        </div>
                                                                    </div>
                                                                    <div className="d-flex sa-inside_bgclr">
                                                                        <div className="d-flex" onClick={() => ConnectToWallet('walletConnect')}>
                                                                            <img
                                                                                src="images/wconnect.png"
                                                                                alt=""
                                                                                className="sa-vector_image"
                                                                                width={40}
                                                                                height={30}
                                                                            />
                                                                            <h6
                                                                                className={
                                                                                    agreementOk ? "sa-active_text" : "sa-chain_text"
                                                                                }
                                                                            >
                                                                                {" "}
                                                                                WalletConnect
                                                                            </h6>
                                                                        </div>
                                                                    </div>
                                                                    <div className="d-flex sa-inside_bgclr">
                                                                        <div className="d-flex" onClick={() => ConnectToWallet('metaMaskWallet')}>
                                                                            <img
                                                                                src="images/TrustWallet.png"
                                                                                alt=""
                                                                                className="sa-vector_image"
                                                                                width={40}
                                                                                height={30}
                                                                            />
                                                                            <div
                                                                                className={
                                                                                    agreementOk ? "sa-active_text" : "sa-chain_text"
                                                                                }
                                                                            >
                                                                                {" "}
                                                                                TrustWallet
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className="d-flex sa-inside_bgclr">
                                                                        <div className="d-flex" onClick={() => ConnectToWallet('TokenPocket')}>
                                                                            <img
                                                                                src="images/TokenPocket.png"
                                                                                alt=""
                                                                                className="sa-vector_image"
                                                                                width={40}
                                                                                height={30}
                                                                            />
                                                                            <div
                                                                                className={
                                                                                    agreementOk ? "sa-active_text" : "sa-chain_text"
                                                                                }
                                                                            >
                                                                                {" "}
                                                                                Token Pocket
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className="d-flex sa-inside_bgclr">
                                                                        <div className="d-flex" onClick={() => ConnectToWallet('TronLink')}>
                                                                            <img
                                                                                src="images/TronLink.jpg"
                                                                                alt=""
                                                                                className="sa-vector_image"
                                                                                width={40}
                                                                                height={30}
                                                                            />
                                                                            <div
                                                                                className={
                                                                                    agreementOk ? "sa-active_text" : "sa-chain_text"
                                                                                }
                                                                            >
                                                                                {" "}
                                                                                TronLink
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        {/* <button className="btn  connect-wallet-btn "  >
                Connect to a Wallet </button> */}
                                        {/* <div className="logoo">
            <img src='images/ollygroup.png' alt='ollswap_logo'
              width={100} />
             </div>
               <div>
               <div>
  {/* <!-- Button trigger modal --> */}
                                        {/* <button >
              &nbsp;&nbsp; Connect &nbsp; &nbsp;
              </button> */}
                                    </div>
                                    {/* <img src='/images/btn.png' style={{marginLeft:'10px'}} className="image" /> */}
                                    {/* <div className=" mining-menu align-self-center ms-4">
              <img src="./RightSectionImages/btn.png" alt="" />
            </div> */}
                                </div>
                            </div>
                            <div className="container content-container mt-md-2">
                                <div className="content mx-auto p-4">
                                    <div
                                        className="heading-btns-container d-flex justify-content-between align-items-center">
                                        <div className="heading-text">SWAP</div>

                                        <div className="btn-group">
                                            {/* <button className="btn btn-1 ">
                  <img src="./RightSectionImages/btn1.png" alt="" />
                </button>
                <button className="btn btn-2 ms-2">
                  <img src="./RightSectionImages/btn2.png" alt="" />
                </button> */}
                                            {/* <button className="btn btn-3 ms-2">
                  <img src="./RightSectionImages/btn3.png" alt="" />
                </button>
                {/* <button className="btn btn-4 ms-2">
                  <img src="./RightSectionImages/btn4.png" alt="" />
                </button> */}
                                        </div>
                                    </div>
                                    <div className="title-input-group-w-menu my-4">
                                        <div className="title d-flex text-white justify-content-between">
                                            <div className="text">Pay</div>
                                            {/* <div className="text">
                  <link rel="stylesheet" href="" />
                  Available: 500
                </div> */}
                                        </div>
                                        <div className="input-group-w-menu d-flex mt-2 ">
                                            <button
                                                onClick={() => {
                                                    setPairType('TRADE');
                                                    pairTypeRef.current = 'TRADE'
                                                    selectBlockchain()
                                                }}
                                                type="button"
                                                className="btn  dropdown-btn d-flex align-items-center p-3 "
                                                data-bs-toggle="modal"
                                                data-bs-target="#openTradeModal"
                                            >
                                                <div className="d-flex align-items-center pe-5">
                                                    <img
                                                        src={`./images/${selectedPairs.tradePair.ticker}.png`}
                                                        className="me-2"
                                                        alt="..."
                                                        width='24'
                                                    />
                                                    {selectedPairs.tradePair.ticker}
                                                </div>

                                                <img
                                                    src="./RightSectionIcons/arrow-down.png"
                                                    className=""
                                                    alt="..."
                                                />
                                            </button>

                                            <div
                                                className="modal fade"
                                                id="openTradeModal"
                                                tabIndex="-1"
                                                aria-labelledby="exampleModalLabel"
                                                aria-hidden="true"
                                            >
                                                <div className="modal-dialog modal-dialog-centered ">
                                                    <div className="modal-content px-4 py-4 ">
                                                        <div className="modal-header align-items-start p-0 border-0">
                                                            <div className="modal-title" id="exampleModalLabel">
                                                                Select Token
                                                            </div>
                                                            <button
                                                                type="button"
                                                                className="btn-close pe-3 "
                                                                data-bs-dismiss="modal"
                                                                aria-label="Close"
                                                            >
                                                                <img
                                                                    src="./RightSectionIcons/close-small.png"
                                                                    alt=""
                                                                />
                                                            </button>
                                                        </div>
                                                        <div className="modal-body px-0">
                                                            {/* <div className="search-container d-flex align-items-center ps-3">
                          <img
                            src="./RightSectionIcons/search.png"
                            width="11.5px"
                            height="11.5px"
                            alt=""
                          />
                          <input
                            class="form-control  search-input "
                            type="search"
                            placeholder="Search token name or contract address"
                            aria-label="Search"
                          />
                        </div> */}
                                                            <div className="horiziontal-btn-scroll-container mt-3">
                                                                <button onClick={() => selectBlockchain()}
                                                                        className={currencyList.selectedBlockchain === null ? "btn btn-active" : "btn mx-2"}>ALL
                                                                </button>
                                                                {loopBlockchains()}
                                                            </div>
                                                        </div>
                                                        <div className="tokens-container">
                                                            {displayCurrencies}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <input
                                                type="number"
                                                className="form-control text-end"
                                                aria-label="Server"
                                                placeholder="0"
                                                name="trade_amount"
                                                value={tradePair.trade_amount}
                                                onChange={changeTradePairs}
                                            />
                                        </div>
                                    </div>
                                    <div className=" d-flex justify-content-center my-4">
                                        <img
                                            className="card-exchange"
                                            src="./RightSectionIcons/ex.png  "
                                            alt=""
                                        />
                                    </div>
                                    <div className="title-input-group-w-menu ">
                                        <div className="title d-flex text-white justify-content-between">
                                            <div className="text">Receive (Estimated)</div>
                                            {/* <div className="text">
                  <link rel="stylesheet" href="" />
                  Available: 1,200
                </div> */}
                                        </div>
                                        <div className="input-group-w-menu d-flex mt-2 ">
                                            <button
                                                onClick={() => {
                                                    setPairType('BASE');
                                                    pairTypeRef.current = 'BASE'
                                                    selectBlockchain()
                                                }}
                                                type="button"
                                                className="btn  dropdown-btn d-flex align-items-center  "
                                                data-bs-toggle="modal"
                                                data-bs-target="#exampleModal3"
                                            >
                                                <div className="d-flex align-items-center  pe-5">
                                                    <img
                                                        src={`./images/${selectedPairs.basePair.ticker}.png`}
                                                        className="me-2"
                                                        alt="..."
                                                        width='24'
                                                    />
                                                    {selectedPairs.basePair.ticker}
                                                </div>

                                                <img
                                                    src="./RightSectionIcons/arrow-down.png"
                                                    className=""
                                                    alt="..."
                                                />
                                            </button>

                                            <div
                                                className="modal fade"
                                                id="exampleModal3"
                                                tabIndex="-1"
                                                aria-labelledby="exampleModalLabel"
                                                // aria-hidden="true"
                                            >
                                                <div className="modal-dialog modal-dialog-centered ">
                                                    <div className="modal-content px-4 py-4 ">
                                                        <div className="modal-header align-items-start p-0 border-0">
                                                            <div className="modal-title" id="exampleModalLabel">
                                                                Select Token
                                                            </div>
                                                            <button
                                                                type="button"
                                                                className="btn-close pe-3 "
                                                                data-bs-dismiss="modal"
                                                                aria-label="Close"
                                                            >
                                                                <img
                                                                    src="./RightSectionIcons/close-small.png"
                                                                    alt=""
                                                                />
                                                            </button>
                                                        </div>
                                                        <div className="modal-body px-0">
                                                            {/*<div
                                                                className="search-container d-flex align-items-center ps-3">
                                                                <img
                                                                    src="./RightSectionIcons/search.png"
                                                                    width="11.5px"
                                                                    height="11.5px"
                                                                    alt=""
                                                                />
                                                                <input
                                                                    className="form-control  search-input "
                                                                    type="search"
                                                                    placeholder="Search token name or contract address"
                                                                    aria-label="Search"
                                                                />
                                                            </div>*/}
                                                            <div className="horiziontal-btn-scroll-container mt-3">
                                                                <button onClick={() => selectBlockchain()}
                                                                        className={currencyList.selectedBlockchain === null ? "btn btn-active" : "btn mx-2"}>ALL
                                                                </button>
                                                                {loopBlockchains()}
                                                            </div>
                                                        </div>
                                                        <div className="tokens-container">
                                                            {displayCurrencies}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <input
                                                type="number"
                                                className="form-control text-end p-3"
                                                aria-label="Server"
                                                placeholder="0"
                                                name='est_base_amount'
                                                value={tradePair.est_base_amount}
                                                onChange={changeTradePairs}
                                            />
                                        </div>
                                    </div>
                                    <div className="rate-container d-flex justify-content-center my-4 ">
                                        <div className="rate pe-2">1 { selectedPairs.tradePair.ticker } = {tradePair.trade_price} { selectedPairs.basePair.ticker }</div>
                                        <img src="./RightSectionIcons/rate.png" alt="" className="d-none"/>
                                    </div>
                                    <div className="input-group mb-3 sa-text_box">
                                        <input
                                            type="text"
                                            className="form-control"
                                            placeholder="Recipient's address"
                                            name="recipient_address"
                                            value={tradePair.recipient_address}
                                            onChange={handleStaticChange}
                                        />
                                    </div>
                                    <div className="confirm-btn-text">
                                        <button
                                            className="btn btn-green"
                                            onClick={() => initTrade()}
                                        >Confirm Order</button>
                                        {/* <div className="text text-center py-2">
                Enter an amount to see more trading details
              </div> */}
                                    </div>
                                    <div className="divider-horizontal"></div>
                                    <div className="bottom  d-flex justify-content-between">
                                        <div className="left text-start">
                                            {/* <div className="p">Exchange Route</div> */}
                                            <div className="p">Reference price</div>
                                            <div className="p">Fee</div>
                                            <div className="p">Estimated amount</div>
                                            <div className="p">Maximum</div>
                                        </div>
                                        <div className="right text-white text-end">
                                            {/* <div className="p">SWFT</div> */}
                                            <div className="p">1 { selectedPairs.tradePair.ticker } = {tradePair.trade_price} { selectedPairs.basePair.ticker }</div>
                                            <div className="p">0.20%</div>
                                            <div className="p"> {tradePair.est_base_amount} { selectedPairs.basePair.ticker }</div>
                                            <div className="p"> {tradePair.trade_liquidity} { selectedPairs.tradePair.ticker }</div>
                                        </div>
                                    </div>

                                    {/* <div className="trade-reward d-flex justify-content-between mt-4">
              <div className="trade d-flex align-items-center ">
                <div className="text me-2">Trade Mining</div>
                <img src="./RightSectionIcons/quetionmark.png" alt="" />
              </div>
              <div className="reward d-flex ">
                <div className="max-reward">Max Reward 5.04 DEX</div>
                <div className="dollar ms-2 ">$16.68</div>
              </div>
            </div> */}
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div className="buttons pt-8 mt-8 d-none">
                <button
                    type="button"
                    className="chakra-button css-1fff88k"
                    onClick={() => setIsMobile(!isMobile)}
                >
                    <span className="chakra-button__icon css-1qx7bcs"></span>
                    {isMobile === true
                        ? "VIEW GRAPH/TRADING HISTORY"
                        : "HIDE GRAPH/TRADING HISTORY"}
                </button>
            </div>
        </>
    );
}

export default App;
