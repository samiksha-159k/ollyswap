import React from 'react'
import './THistory.css'

function THistory() {
  return (
    <div className=''>
        <div className="container sa-income mt-2 px-0">
          <h3 className='sa-table_head'>Trading History</h3>
          <div style={{border:'10px solid red !important'}}>
                <table className="table table-borderless table-responsive-sm tabulardata ">
                    <thead>
                    <tr className="sa-table_header  ">
                        <th scope="col" className="  ">
                            DATE/TIME
                        </th>
                        <th scope="col" className="">
                            PAIR
                        </th>
                        <th scope="col" className="">
                            TOKENS
                        </th>
                        <th scope="col" className="">
                            TXN #
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr className='sa-border' style={{borderRadius:'20px !important' }}>
                        <td>
                            18/04/2022 <br/> 3:47 PM
                        </td>
                        <td>
                            BUSD/ETH
                        </td>
                        <td>20,8399.97 </td>
                        <td>0x23rf56...<br/>0x2dc52</td>
                    </tr>
                    <tr className='sa-border'>
                        <td>
                            18/04/2022 <br/> 3:47 PM
                        </td>
                        <td>
                            BUSD/ETH
                        </td>
                        <td>20,8399.97 </td>
                        <td>0x23rf56...<br/>0x2dc52</td>
                    </tr>
                    <tr className='sa-border'>
                        <td>
                            18/04/2022<br/> 3:47 PM
                        </td>
                        <td>
                            BUSD/ETH
                        </td>
                        <td>20,8399.97 </td>
                        <td>0x23rf56...<br/>0x2dc52</td>
                    </tr>
                    <tr className='sa-border'>
                        <td>
                            18/04/2022 <br/>3:47 PM
                        </td>
                        <td>
                            BUSD/ETH
                        </td>
                        <td>20,8399.97 </td>
                        <td>0x23rf56...<br/>0x2dc52</td>
                    </tr>
                    <tr className='sa-border'>
                        <td>
                            18/04/2022 <br/>3:47 PM
                        </td>
                        <td>
                            BUSD/ETH
                        </td>
                        <td>20,8399.97 </td>
                        <td>0x23rf56...<br/>0x2dc52</td>
                    </tr>
                    </tbody>
                </table>
                </div>
            </div>
    </div>
  )
}

export default THistory