import React from 'react'
import '../Connect Wallet Popup/ConnectWPopup.css'
import '../Accounts/Account.css'
import '../Right-section/RightSection.css'

function Account() {
  return (
   <div>
       <div className='container sa-container'>
                 <div className='sa-bgclr sa-width'>
                    <div>
                      <h1 className='sa-acc_heading pt-3' >Account <span> 
                      {/* <button type="button" class="btn-close btn-close-white sa-acc_btn " aria-label="Close"></button> */}
                      <i className="fa-solid fa-xmark sa-Acc_font_Awesome" ></i>
                      {/* <button
                          type="button"
                          class="btn-close pe-3 "
                          data-bs-dismiss="modal"
                          aria-label="Close"
                        >
                          <img
                            src="./RightSectionIcons/close-small.png"
                            alt=""
                          />
                        </button> */}
                      </span>
                      </h1>
                  </div>
                  <div>
                      <h1 className=' sa-Acc_number' >0xBAD7...E116 <span className='sa-acc_images'> 
                         <img src='/images/share.png' alt='' className='sa_share_image' />
                         <img src='/images/copy.png' alt='' className='sa_copy_image'/>
                         </span>
                      </h1>
                  </div>
                  <div className='d-flex column col-12 sa_Acc_buttons'>
                      <span>
                         
                  <button type="button" class="btn btn-secondary sa_acc_secondary_button "> <img src='/images/Group.png' className='sa-btnnnnn' alt=''/>Switch Wallet</button></span>
                  <button type="button" class="btn btn-primary sa_acc_primary_button">Disconnect Wallet</button>

                  </div>
                  <div>
                      <h1 className='sa-Acc-subheading mt-4' >Recent Transaction <span> 
                        <a href='##' className='sa_reference'>Clear all</a>
                         </span>
                      </h1>
                  </div>
                  <div>
                      <h1 className=' sa-acc_menuheading mt-4' >Stake 
                      <i class="fa-solid fa-square-arrow-up-right sa-sqaure-arrow"></i>
                      <span> 
                      
                      <i class="fa-solid fa-check sa-font_Awesome" style={{color:'#53F3C3'}}></i>
                         </span>
                      </h1>
                  </div>
                  <div>
                      <h1 className='sa-acc_menuheading mt-4' >Approve DEXDLP 
                      <i class="fa-solid fa-square-arrow-up-right sa-sqaure-arrow"></i><span> 
                      <i class="fa-solid fa-check sa-font_Awesome" style={{color:'#53F3C3'}}></i>
                         </span>
                      </h1>
                  </div>
                  <div>
                      <h1 className='sa-acc_menuheading mt-4' >
                      
                      ADD Liquidity
                      <i class="fa-solid fa-square-arrow-up-right sa-sqaure-arrow"></i>
                      <h6 className='sa-acc_submenuheading mt-1'>7.4812029 DEX <br/>5812.291025829 MTV
                      <span> 
                      <i class="fa-solid fa-check sa-font_Awesome" style={{color:'#53F3C3'}}></i>
                         </span></h6></h1>
                   
                  </div>
                  <div>
                      <h1 className='sa-acc_menuheading mt-3' >Approve DEX
                      <i class="fa-solid fa-square-arrow-up-right sa-sqaure-arrow"></i>
                      <span> 
                      <i class="fa-solid fa-check sa-font_Awesome" style={{color:'#53F3C3'}}></i>
                         </span>
                      </h1>
                  </div>
                  <div>
                      <h1 className='sa-acc_menuheading mt-4' >Approve MTV 
                      <i class="fa-solid fa-square-arrow-up-right sa-sqaure-arrow"></i><span> 

                      <i class="fa-solid fa-check sa-font_Awesome" style={{color:'#53F3C3'}}></i>
                         </span>
                      </h1>
                  </div>
                  <div>
                      <h1 className='sa-acc_menuheading mt-4' >Swap
                      <i class="fa-solid fa-square-arrow-up-right sa-sqaure-arrow"></i>
                      <h6 className='sa-acc_submenuheading mt-1'>0.045125 BNB to 2132.51853983 MTV
                       <span> 
                       
                      <i class="fa-solid fa-xmark sa-font_Awesome" style={{color:'#FF6370'}}></i>
                       </span></h6>
                         </h1>
                  </div>

                  </div>
                  </div>
   </div>
  )
}

export default Account

