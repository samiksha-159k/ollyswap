import React, {useState} from 'react'
import './ConnectWPopup.css'



function ConnectWPopup() {
    const[status , setstatus] = useState(false);

    return (
        <div>
            {/* <!-- Button trigger modal --> */}
            <button type="button" className="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal" style={{marginTop:50}}>
                Connect To Wallet
            </button>

            {/* <!-- Modal --> */}
            <div className="modal fade" id="exampleModal" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div className="modal-dialog">
                    <div className="modal-content sa-modal-content">
                        {/* <div class="modal-header">
                                 <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                             </div> */}
                        <div className="modal-body sa-modal-body">
                            <div className='container sa-container'>
                                <div className='sa-bgclr sa-width'>
                                    <div>
                                        <h1 className=' sa-heading' >Connect Wallet <span>
                         <i className="fa-solid fa-xmark sa-font_Awesome" ></i></span>
                                        </h1>
                                    </div>

                                    <div className='sa-inside_bgclr'>
                                        <div className="form-check">
                                            <input className=" sa-box form-check-input" type="checkbox" value="" id="flexCheckDefault"
                                                   onClick={()=>setstatus(!status)} />
                                            <label className="form-check-label sa-check" htmlFor="flexCheckDefault">
                                                I have read, understand, and agree to <span className='sa-break'>the  <a href='#'>Terms of Service.</a></span>
                                            </label>
                                        </div>
                                    </div>

                                    <div className='d-flex sa-inside_bgclr'>
                                        <img src='images/metamask.png' alt='metamask image' className='sa-vector_image' width={40} height={30} />
                                        <h6 className={status?'sa-active_text':'sa-chain_text'}> Meta Mask</h6>
                                    </div>

                                    <div className='d-flex sa-inside_bgclr'>
                                        <img src='images/Layer.png' alt='vector image' className='sa-vector_image' width={40} height={30} />
                                        <h6 className={status?'sa-active_text':'sa-chain_text'}> Binance Chain Wallet</h6>
                                    </div>

                                    <div className='d-flex sa-inside_bgclr'>
                                        <img src='images/wconnect.png' alt='wallect Connect image' className='sa-vector_image' width={40} height={30} />
                                        <h6 className={status?'sa-active_text':'sa-chain_text'}> WalletConnect</h6>
                                    </div>

                                    <div className='d-flex sa-inside_bgclr'>
                                        <img src='images/TrustWallet.png' alt='portis image' className='sa-vector_image' width={40} height={30} />
                                        <h6 className={status?'sa-active_text':'sa-chain_text'}> TrustWallet</h6>
                                    </div>

                                    <div className='d-flex sa-inside_bgclr'>
                                        <img src='images/TokenPocket.png' alt='portis image' className='sa-vector_image' width={40} height={30} />
                                        <h6 className={status?'sa-active_text':'sa-chain_text'}> Token Pocket</h6>
                                    </div>
                                    <div className='d-flex sa-inside_bgclr'>
                                        <img src='images/TronLink.jpg' alt='portis image' className='sa-vector_image' width={40} height={30} />
                                        <h6 className={status?'sa-active_text':'sa-chain_text'}> TronLink</h6>
                                    </div>
                                </div>

                            </div>
                        </div>

                        {/* <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div> */}
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ConnectWPopup