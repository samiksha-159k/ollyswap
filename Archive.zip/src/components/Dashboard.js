import React, { useState } from "react";
import Header from "./Header/Header";
import Graph from "./Header/graph/Graph";
import Calculator from "./Calculator/Calculator";
// import THistory from './Trading History/THistory';

const Dashboard = () => {
  const [isMobile, setIsMobile] = useState(true);

  return (
    <>
      <div
        className=" desk-top-view d-flex flex-md-nowrap flex-wrap ps-md-4 ps-0 "
        style={{ backgroundColor: "rgba(26, 27, 35, 1)" , paddingBottom:"40px" }}
      >
        <div className="col-md-8 col-12 d-flex flex-column">
          <Header />
          <div className="graph d-md-block d-none">
            <Graph />
          </div>  
        </div>
          {/* <div className="col-md-4 d-md-block d-none">
            <Calculator />
          </div> */}
        <div className="col-md-4 col-12">
          {isMobile ? <Calculator /> : <Graph />}
        </div>
      </div>

      <div className="buttons pt-8 mt-8">
        <button
          type="button"
          className="chakra-button css-1fff88k"
          onClick={() => setIsMobile(!isMobile)}
        >
          <span className="chakra-button__icon css-1qx7bcs"></span>
          {isMobile === true
            ? "VIEW GRAPH/TRADING HISTORY"
            : "HIDE GRAPH/TRADING HISTORY"}
        </button>
      </div>
    </>
  );
};

export default Dashboard;
