import React, {useState} from 'react'
import { ResponsiveContainer, AreaChart, XAxis, YAxis, Area } from "recharts";
import { format, parseISO, subDays } from "date-fns";
import THistory from "../../Trading History/THistory";
import "./graph.css";



const data = [];
for (let num = 30; num >= 0; num--) {
  data.push({
    date: subDays(new Date().getTime(), num).toISOString().substr(0, 10),
    value: 1 + Math.random(),
  });
}

export default function Home() {
  return (
    <div className="graph-container-info-container container  pt-4">
      <div className="info-container ">
        <div className="row">
          <div className="ic-token-name-refresh-button d-flex align-items-center py-3">
            <img
              src="./RightSectionImages/BUSD.png"
              width="26.59px"
              height="26.67px"
              alt=""
              className="busd-img"
            />
            <img
              src="./RightSectionImages/image3.png"
              width="26.59px"
              height="26.67px"
              alt=""
              className="usdc-img"
            />
            <div className="token-name text-white px-2">BUSD/USDC</div>
            <img
              src="./RightSectionIcons/rate.png"
              width={18}
              height={17}
              alt=""
              className=""
            />
          </div>
          <div className="MainText token-number text-white ">1.0005 USDC</div>
          <div className="token-duration "></div>
        </div>
      </div>
      <div className="duration-wise-data-updated d-flex justify-content-between flex-md-nowrap flex-wrap">
        <div className="past-24-hours text-white ">
          <div className="text-green pt-2">
            +227.543364 USDC <span className="text-white">Past 24 Hours</span>
          </div>
        </div>
        {/* <div className="month-week-hours-btns mx-md-0 mx-auto">
          <button className="mwh-btn m-2" style={{backgroundColor:"#3B3C4E", color:"white", borderRadius:"12px",border:"none",fontWeight: "400px"}}>24H</button>
          <button className="mwh-btn2 m-2">1W</button>
          <button className="mwh-btn2 m-2">1M</button>
        </div> */}
      </div>

      <ResponsiveContainer width="100%" height={500}>
        <AreaChart data={data}>
          <defs>
            <linearGradient id="color" x1="0" y1="0" x2="0" y2="1">
              <stop
                offset="0%"
                stopColor="rgba(26, 239, 175, 1)"
                stopOpacity={0.7}
              />
              <stop
                offset="75%"
                stopColor="rgba(26, 239, 175, 1)"
                stopOpacity={0.1}
              />
            </linearGradient>
          </defs>

          <Area
            dataKey="value"
            stroke="rgba(26, 239, 175, 1)"
            fill="url(#color)"
          />

          <XAxis
            dataKey="date"
            axisLine={false}
            tickLine={false}
            tickFormatter={(str) => {
              const date = parseISO(str);
              if (date.getDate() % 7 === 0) {
                return format(date, "MMM, d");
              }
              return "";
            }}
          />

          <YAxis
            datakey="value"
            axisLine={false}
            tickLine={false}
            tickCount={8}
            tickFormatter={(number) => `$${number.toFixed(2)}`}
          />

          {/* <Tooltip content={<CustomTooltip />} /> */}

          {/* <CartesianGrid opacity={0.1} vertical={false} /> */}
        </AreaChart>
      </ResponsiveContainer>
      <div className="d-md-none d-block">
       <THistory/>

      </div>
          
    </div>
  );
}
