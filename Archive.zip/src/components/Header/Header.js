import "./Header.css";
import React, {useState} from "react";
//import Graph from "./graph/Graph";
import "../Connect Wallet Popup/ConnectWPopup.css";


const Header = () => {
    const [agreementOk, setAgreementOk] = useState(false);
    function ConnectToWallet(connector) {
        if(agreementOk) {
            console.log('Connect to', connector);
            let modal = document.getElementsByClassName('modal');
            modal.modal("close");
        }

    }

    return (
        <div className="header">
            <nav class="navbar ">
                <div class="container">
                    <a class="navbar-brand" href="/">
                        <img
                            src="images/ollygroup.png"
                            alt=""
                            width="163px"
                            height="38px"
                        />
                    </a>

                    <button
                        type="button"
                        className="connect-wallet-btn btn btn-connect d-md-none d-block"
                        data-bs-toggle="modal"
                        data-bs-target="#exampleModal1"
                    >
                        Connect
                    </button>
                    <div
                        className="modal fade "
                        id="exampleModal2"
                        tabIndex="-2"
                        aria-labelledby="exampleModalLabel"
                        aria-hidden="true"
                    >
                        <div className="modal-dialog d-block">
                            <div className="modal-content sa-modal-content">
                                {/* <div class="modal-header">
                                 <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                             </div> */}
                                <div className="modal-body sa-modal-body">
                                    <div className="container sa-container ">
                                        <div className="sa-bgclr sa-width">
                                            <div>
                                                <h1 className=" sa-heading d-flex align-items-baseline justify-content-between">
                                                    Connect Wallet{" "}
                                                    <span>
                                  <button
                                      type="button shodow-none"
                                      class="btn-close pe-3"
                                      data-bs-dismiss="modal"
                                      aria-label="Close"
                                  >
                          <img
                              src="./RightSectionIcons/close-small.png"
                              alt=""
                          />
                        </button>
                                                        {/* <i className="fa-solid fa-xmark sa-font_Awesome"></i> */}
                                </span>
                                                </h1>
                                            </div>
                                            <div className="sa-inside_bgclr">
                                                <div className="form-check">
                                                    <input
                                                        className=" sa-box form-check-input"
                                                        type="checkbox"
                                                        value=""
                                                        id="flexCheckDefault"
                                                        onClick={() => setAgreementOk(!agreementOk)}
                                                    />
                                                    <label
                                                        className="form-check-label sa-check"
                                                        htmlFor="flexCheckDefault"
                                                    >
                                                        I have read, understand, and agree to{" "}
                                                        <span className="sa-break">
                                    the <a href="/">Terms of Service.</a>
                                  </span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div className="d-flex sa-inside_bgclr">
                                                <div className="d-flex" onClick={() => ConnectToWallet('metaMaskWallet')}>
                                                    <img
                                                        src="images/metamask.png"
                                                        alt=""
                                                        className="sa-vector_image"
                                                        width={40}
                                                        height={30}
                                                    />
                                                    <div
                                                        className={
                                                            agreementOk ? "sa-active_text" : "sa-chain_text"
                                                        }
                                                    >
                                                        {" "}
                                                        Meta Mask
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="d-flex sa-inside_bgclr">
                                                <div className="d-flex" onClick={() => ConnectToWallet('binanceChainWallet')}>
                                                    <img
                                                        src="images/Layer.png"
                                                        alt=""
                                                        className="sa-vector_image"
                                                        width={40}
                                                        height={30}
                                                    />
                                                    <div
                                                        className={
                                                            agreementOk ? "sa-active_text" : "sa-chain_text"
                                                        }
                                                    >
                                                        {" "}
                                                        Binance Chain Wallet
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="d-flex sa-inside_bgclr">
                                                <div className="d-flex" onClick={() => ConnectToWallet('walletConnect')}>
                                                    <img
                                                        src="images/wconnect.png"
                                                        alt=""
                                                        className="sa-vector_image"
                                                        width={40}
                                                        height={30}
                                                    />
                                                    <div
                                                        className={
                                                            agreementOk ? "sa-active_text" : "sa-chain_text"
                                                        }
                                                    >
                                                        {" "}
                                                        WalletConnect
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="d-flex sa-inside_bgclr">
                                                <div className="d-flex" onClick={() => ConnectToWallet('walletConnect')}>
                                                    <img
                                                        src="images/TrustWallet.png"
                                                        alt=""
                                                        className="sa-vector_image"
                                                        width={40}
                                                        height={30}
                                                    />
                                                    <div
                                                        className={
                                                            agreementOk ? "sa-active_text" : "sa-chain_text"
                                                        }
                                                    >
                                                        {" "}
                                                        TrustWallet
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="d-flex sa-inside_bgclr">
                                                <div className="d-flex" onClick={() => ConnectToWallet('TokenPocket')}>
                                                    <img
                                                        src="images/TokenPocket.png"
                                                        alt=""
                                                        className="sa-vector_image"
                                                        width={40}
                                                        height={30}
                                                    />
                                                    <div
                                                        className={
                                                            agreementOk ? "sa-active_text" : "sa-chain_text"
                                                        }
                                                    >
                                                        {" "}
                                                        Token Pocket
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="d-flex sa-inside_bgclr">
                                                <div className="d-flex" onClick={() => ConnectToWallet('TronLink')}>
                                                    <img
                                                        src="images/TronLink.jpg"
                                                        alt=""
                                                        className="sa-vector_image"
                                                        width={40}
                                                        height={30}
                                                    />
                                                    <div
                                                        className={
                                                            agreementOk ? "sa-active_text" : "sa-chain_text"
                                                        }
                                                    >
                                                        {" "}
                                                        TronLink
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>





                    {/* <button class="btn btn-connect d-md-none d-block " >Connect</button> */}
                </div>
            </nav>
            {/* <div>
            <img src='images/ollygroup.png' alt='ollswap_logo' className='sa-ollyswap_logo'
            width={100} />
          </div> */}
            {/* <div className=" d-flex">
          <div className="button">OLLY</div>

            <button className="button">Exchange</button>
            <button className="button">Liquidity</button>

            <select
              value="Mining"
              placeholder="Mining"
              defaultValue="Mining"
              className="dropdown"
            >

              <option value="A">Liquidity Mining</option>
              <option value="B">Trading mining</option>
              <option value="C">vFTR</option>
            </select>

            <button className="button">Developer</button>

          </div> */}


        </div>
    );
};
export default Header;
