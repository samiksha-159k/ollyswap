import React, {useState, useEffect, useRef} from "react";
import axios from 'axios'
import "./Calculator.css";
import "../Connect Wallet Popup/ConnectWPopup.css";
import _ from "lodash";
// mport {doTransaction, connectWallet, fetchWalletAddress} from "../../Web3ModalHelper";

// import { useState, useEffect } from "react";
// import Web3Modal from "web3modal"
// import WalletConnectProvider from "@walletconnect/web3-provider"
// import { ethers } from "ethers";

//  let web3Modal;
//   const providerOptions ={
//     wallconnect:{
//       package: WalletConnectProvider,
//       options:{
//         rpc :{42: process.env.NEXT_PUBLIC_RPC_URL},
//       },
//     },

//   }
//   if (typeof window !== "undefined") {
//     web3Modal = new Web3Modal({
//       cacheProvider: false,
//       providerOptions, // required
//     });
//   }

const Calculator = () => {

  const [status, setstatus] = useState(false);
  const [state, setState] = useState({ loading: false, currencies: null, allList: [] })
  const stateref = useRef(state)
  const [displayList, setDisplayList] = useState(null)
  const [selectedCat, setselectedCat] = useState(null)
  const [selectedCurrency, setselectedCurrency] = useState({ image: 'BUSD.png' , name: 'BUSD'})
  const [selectedCurrency2, setselectedCurrency2] = useState({ image: 'USDC.png' , name: 'USDC'})

  const [payType, setPayType] = useState(null)
  const payTypeRef = useRef(payType)

  const tradeInputRef = useRef(null)
  const baseInputRef = useRef(null)


  const currencyCats = ['BSC','SOL','TRX', 'MATIC', 'ETH', 'BSC', 'SOL', 'TRX', 'MATIC'] //all token/currency categories
  useEffect(() => {
    console.log('changed made')
    getCurrencies()
    // setTimeout(()=> {
    //   allTokenListModal()
    // },5000)
  },[]);

  useEffect(() => {
    console.log('updated state>',state)
    if(state.currencies !== null){
      console.log(state.currencies)
      console.log('triggering list')
      allTokenListModal()
    }
  },[state]);

  const getCurrencies = () => {
    axios.get(`${process.env.REACT_APP_API_URL}/currencies`)
    .then(response => {
        console.log('response',response)
        if (response.status === 200) {
            //proceed...
            var allList = []
            _.map(response.data.data, (item,index) => {
                //console.log('item',item,index)
              _.map(item, (each) => {
                allList.push({...each, cat: index })
              })
            })
            //console.log('alllist',allList)
            setState(prev => ({...prev, loading: false, currencies: response.data.data, allList }))
            //stateref.current = { loading: false, currencies: response.data.data, allList }
        }
        else {
            // throw error and go to catch block
            //throw new Error("Error");
        }
    }).catch(error => {
      setState(prev => ({...prev, loading: false }))
    })
  }

  const loopCurrencyCatList = () => {
    // displaying all currency/token categories in the modal
    var displayItems =  _.map(state.currencies, (each, index) => {
      console.log('index',index,'each',each)
      return <button onClick={()=>allTokenListModal(index)} className={selectedCat === index ? "btn btn-active" : "btn mx-2"}>{index}</button>
    })
    console.log('displayItems x',displayItems)
    return displayItems;
  }

  // const allTokenListModal = () => {
  //   //console.log('state.currencies',stateref.current)
  //   var displayItems = []
  //   _.map(state.currencies, (item,index) => {
  //       console.log('item',item,index)
  //     _.map(item, (each) => {
  //         console.log('each',each)
  //         displayItems.push (
  //               <div className="token d-flex justify-content-between py-3 ps-2 pe-3 mb-3">
  //                   <div className="token-img-token-name d-flex align-items-center">
  //                     <img
  //                       src="./RightSectionImages/image1.png"
  //                       width="22px"
  //                       height="22px"
  //                       alt=""
  //                     />
  //                     <div className="token-name ms-3">
  //                       <div className="name mb-0">{each.ticker}</div>
  //                       <div className="sub-name mb-0">{index}</div>
  //                     </div>
  //                   </div>
  //                   <div className="token-rate  align-self-center">
  //                     {each.market_price}
  //                   </div>
  //               </div>
  //           )
  //       })

  //       console.log('displayItems',displayItems)

  //   })
  //   console.log('display',displayItems)
  //   return displayItems;
  // }

  const clickedCurrency = (image, name) => {
    console.log('payTypeRef.current',payTypeRef.current)
    if(payTypeRef.current === 'trade'){
      setselectedCurrency(prev => ({...prev, image, name }))
      console.log('focus')
      tradeInputRef.current.focus()
    } else {
      setselectedCurrency2(prev => ({...prev, image, name }))
      baseInputRef.current.focus()
    }
  }


  const allTokenListModal = (cat = null) => {
      //console.log('state.currencies',stateref.current)
        var displayItems = []
        _.map(state.allList, (each) => {
            console.log('each',each)
            if(cat == null || cat !== null && each.cat == cat ) {
              displayItems.push(
                    <div onClick={()=> clickedCurrency('BUSD.png',each.ticker) } className="token d-flex justify-content-between py-3 ps-2 pe-3 mb-3">
                        <div className="token-img-token-name d-flex align-items-center">
                          {/* <img
                            src="./RightSectionImages/image1.png"
                            width="22px"
                            height="22px"
                            alt=""
                          /> */}
                          <div className="token-name ms-3">
                            <div className="name mb-0">{each.ticker}</div>
                            <div className="sub-name mb-0">{each.cat}</div>
                          </div>
                        </div>
                        <div className="token-rate  align-self-center">
                          {each.market_price}
                        </div>
                    </div>
                )
            }
          })
      console.log('display',displayItems)
      //setState(prev => ({...prev, selectedCat: cat }))
      setDisplayList(displayItems)
      setselectedCat(cat)
      //return displayItems;
    }


  // const [show, setShow] = useState(true);
  // const [isConnected, setIsConnected] = useState(false);
  // const [hasMetamask, setHasMetamask] = useState(false);
  // const [signer, setSigner] = useState(undefined);

  // useEffect(() => {
  //   if (typeof window.ethereum !== "undefined") {
  //     setHasMetamask(true);
  //   }
  // });



  // async function connect(){
  //   if (typeof window.ethereum !== "undefined") {
  //     try {
  //       const web3ModalProvider = await web3Modal.connect();
  //       setIsConnected(true);
  //       const provider = new ethers.providers.Web3Provider(web3ModalProvider);
  //       setSigner(provider.getSigner());
  //     } catch (e) {
  //       console.log(e);
  //     }
  //   } else {
  //     setIsConnected(false);
  //   }
  // }
  // async function execute() {
  //   if (typeof window.ethereum !== "undefined") {
  //     const contractAddress = "0x5FbDB2315678afecb367f032d93F642f64180aa3";
  //     const contract = new ethers.Contract(contractAddress, signer);
  //     try {
  //       await contract.store(42);
  //     } catch (error) {
  //       console.log(error);
  //     }
  //   } else {
  //     console.log("Please install MetaMask");
  //   }
  // }

  return (
    <div className="col-12">
      <div className="RightSectionMain d-block ">
        <div className="container d-md-block d-none">
        <div className="top  d-flex  justify-content-center ">
            {/* <div className="user align-self-center">
              <img src="./RightSectionIcons/Group.png" alt="" />
            </div> */}
            <div className="address">
              <div className="eth d-flex align-items-center px-3">
                <img src="./RightSectionIcons/Group.png" alt="" />
                <div class="dropdown ms-1">
                  <button
                    class="btn connect-wallet-btn dropdown-toggle"
                    type="button"
                    id="dropdownMenuButton1"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    1234..56
                  </button>
                  <ul
                    class="dropdown-menu p-2"
                    aria-labelledby="dropdownMenuButton1"
                  >
                    <li className="p-0">
                      <a class="dropdown-item p-0" href="/" >
                        Disabled
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div className="address d-flex ms-2">
              <div className="eth d-flex align-items-center px-2">
                <img src="./RightSectionIcons/vector.png" alt="" />
                <div className="eth-name text-white px-1 ">BSC</div>
              </div>
              <div>
                {/* <!-- Button trigger modal --> */}
                {/* <button >
              &nbsp;&nbsp; Connect &nbsp; &nbsp;
              </button> */}
                <button
                  type="button"
                  className="btn connect-wallet-btn "
                  data-bs-toggle="modal"
                  data-bs-target="#exampleModal1"
                >
                  Connect
                </button>
                {/* <!-- Modal --> */}
                <div
                  className="modal fade "
                  id="exampleModal1"
                  tabIndex="-2"
                  aria-labelledby="exampleModalLabel"
                  aria-hidden="true"
                >
                  <div className="modal-dialog d-md-block d-none">
                    <div className="modal-content sa-modal-content">
                      {/* <div class="modal-header">
                                 <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                             </div> */}
                      <div className="modal-body sa-modal-body">
                        <div className="container sa-container ">
                          <div className="sa-bgclr sa-width">
                            <div>
                              <h1 className=" sa-heading">
                                Connect Wallet{" "}
                                <span>
                                  <button
                                    type="button"
                                    class="btn-close pe-3 "
                                    data-bs-dismiss="modal"
                                    aria-label="Close"
                                  >
                                    <img
                                      src="./RightSectionIcons/close-small.png"
                                      alt=""
                                    />
                                  </button>
                                  {/* <i className="fa-solid fa-xmark sa-font_Awesome"></i> */}
                                </span>
                              </h1>
                            </div>
                            <div className="sa-inside_bgclr">
                              <div className="form-check">
                                <input
                                  className=" sa-box form-check-input"
                                  type="checkbox"
                                  value=""
                                  id="flexCheckDefault"
                                  onClick={() => setstatus(!status)}
                                />
                                <label
                                  className="form-check-label sa-check"
                                  htmlFor="flexCheckDefault"
                                >
                                  I have read, understand, and agree to{" "}
                                  <span className="sa-break">
                                    the <a href="/">Terms of Service.</a>
                                  </span>
                                </label>
                              </div>
                            </div>
                            <div className="d-flex sa-inside_bgclr">
                              <img
                                src="images/metamask.png"
                                alt=""
                                className="sa-vector_image"
                                width={40}
                                height={30}
                              />
                              <h6
                                className={
                                  status ? "sa-active_text" : "sa-chain_text"
                                }
                              >
                                {" "}
                                Meta Mask
                              </h6>
                            </div>
                            <div className="d-flex sa-inside_bgclr">
                              <img
                                src="images/Layer.png"
                                alt=""
                                className="sa-vector_image"
                                width={40}
                                height={30}
                              />
                              <h6
                                className={
                                  status ? "sa-active_text" : "sa-chain_text"
                                }
                              >
                                {" "}
                                Binance Chain Wallet
                              </h6>
                            </div>
                            <div className="d-flex sa-inside_bgclr">
                              <img
                                src="images/wconnect.png"
                                alt=""
                                className="sa-vector_image"
                                width={40}
                                height={30}
                              />
                              <h6
                                className={
                                  status ? "sa-active_text" : "sa-chain_text"
                                }
                              >
                                {" "}
                                WalletConnect
                              </h6>
                            </div>
                            <div className="d-flex sa-inside_bgclr">
                              <img
                                src="images/portis.png"
                                alt=""
                                className="sa-vector_image"
                                width={40}
                                height={30}
                              />
                              <h6
                                className={
                                  status ? "sa-active_text" : "sa-chain_text"
                                }
                              >
                                {" "}
                                Portis
                              </h6>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* <button className="btn  connect-wallet-btn "  >
                Connect to a Wallet </button> */}
              {/* <div className="logoo">
            <img src='images/ollygroup.png' alt='ollswap_logo'
              width={100} />
             </div>
               <div>
               <div>
  {/* <!-- Button trigger modal --> */}
              {/* <button >
              &nbsp;&nbsp; Connect &nbsp; &nbsp;
              </button> */}
            </div>
            {/* <img src='/images/btn.png' style={{marginLeft:'10px'}} className="image" /> */}
            {/* <div className=" mining-menu align-self-center ms-4">
              <img src="./RightSectionImages/btn.png" alt="" />
            </div> */}
          </div>
        </div>
        <div className="container content-container mt-md-2">
          <div className="content mx-auto p-4">
            <div className="heading-btns-container d-flex justify-content-between align-items-center">
              <div className="heading-text">SWAP</div>

              <div className="btn-group">
                {/* <button className="btn btn-1 ">
                  <img src="./RightSectionImages/btn1.png" alt="" />
                </button>
                <button className="btn btn-2 ms-2">
                  <img src="./RightSectionImages/btn2.png" alt="" />
                </button> */}
                {/* <button className="btn btn-3 ms-2">
                  <img src="./RightSectionImages/btn3.png" alt="" />
                </button>
                {/* <button className="btn btn-4 ms-2">
                  <img src="./RightSectionImages/btn4.png" alt="" />
                </button> */}
              </div>
            </div>
            <div className="title-input-group-w-menu my-4">
              <div className="title d-flex text-white justify-content-between">
                <div className="text">Pay</div>
                {/* <div className="text">
                  <link rel="stylesheet" href="" />
                  Available: 500
                </div> */}
              </div>
              <div className="input-group-w-menu d-flex mt-2 ">
                <button
                  onClick={()=>{ console.log('open4trade'); setPayType('trade'); payTypeRef.current = 'trade' }}
                  type="button"
                  class="btn  dropdown-btn d-flex align-items-center p-3 "
                  data-bs-toggle="modal"
                  data-bs-target="#exampleModal2"
                >
                  <div className="d-flex align-items-center pe-5">
                    {/* <img
                      src={`./RightSectionImages/${selectedCurrency.image}`}
                      class="me-2"
                      alt="..."
                    /> */}
                    {selectedCurrency.name}
                  </div>

                  <img
                    src="./RightSectionIcons/arrow-down.png"
                    class=""
                    alt="..."
                  />
                </button>

                <div
                  class="modal fade"
                  id="exampleModal2"
                  tabindex="-1"
                  aria-labelledby="exampleModalLabel"
                  aria-hidden="true"
                >
                  <div class="modal-dialog modal-dialog-centered ">
                    <div class="modal-content px-4 py-4 ">
                      <div class="modal-header align-items-start p-0 border-0">
                        <div class="modal-title" id="exampleModalLabel">
                          Select Token
                        </div>
                        <button
                          type="button"
                          class="btn-close pe-3 "
                          data-bs-dismiss="modal"
                          aria-label="Close"
                        >
                          <img
                            src="./RightSectionIcons/close-small.png"
                            alt=""
                          />
                        </button>
                      </div>
                      <div class="modal-body px-0">
                        {/* <div className="search-container d-flex align-items-center ps-3">
                          <img
                            src="./RightSectionIcons/search.png"
                            width="11.5px"
                            height="11.5px"
                            alt=""
                          />
                          <input
                            class="form-control  search-input "
                            type="search"
                            placeholder="Search token name or contract address"
                            aria-label="Search"
                          />
                        </div> */}
                        <div className="horiziontal-btn-scroll-container mt-3">
                          <button onClick={()=>allTokenListModal()} className={selectedCat === null ? "btn btn-active" : "btn mx-2"}>ALL</button>
                          {loopCurrencyCatList()}
                        </div>
                      </div>
                      <div className="tokens-container">

                        {displayList}


                      </div>
                    </div>
                  </div>
                </div>

                <input
                  type="number"
                  class="form-control text-end"
                  aria-label="Server"
                  placeholder="0"
                  ref={tradeInputRef}
                />
              </div>
            </div>
            <div className=" d-flex justify-content-center my-4">
              <img
                className="card-exchange"
                src="./RightSectionIcons/ex.png  "
                alt=""
              />
            </div>
            <div className="title-input-group-w-menu ">
              <div className="title d-flex text-white justify-content-between">
                <div className="text">Receive (Estimated)</div>
                {/* <div className="text">
                  <link rel="stylesheet" href="" />
                  Available: 1,200
                </div> */}
              </div>
              <div className="input-group-w-menu d-flex mt-2 ">
                <button
                  onClick={()=>{ console.log('open4base'); setPayType('base'); payTypeRef.current = 'base' }}
                  type="button"
                  class="btn  dropdown-btn d-flex align-items-center  "
                  data-bs-toggle="modal"
                  data-bs-target="#exampleModal3"
                >
                  <div className="d-flex align-items-center  pe-5">
                  {/* <img
                    src={`./RightSectionImages/${selectedCurrency2.image}`}
                    class="me-2"
                    alt="..."
                  /> */}
                  {selectedCurrency2.name}
                  </div>

                  <img
                    src="./RightSectionIcons/arrow-down.png"
                    class=""
                    alt="..."
                  />
                </button>

                <div
                  class="modal fade"
                  id="exampleModal3"
                  tabindex="-1"
                  aria-labelledby="exampleModalLabel"
                  // aria-hidden="true"
                >
                  <div class="modal-dialog modal-dialog-centered ">
                    <div class="modal-content px-4 py-4 ">
                      <div class="modal-header align-items-start p-0 border-0">
                        <div class="modal-title" id="exampleModalLabel">
                          Select Token
                        </div>
                        <button
                          type="button"
                          class="btn-close pe-3 "
                          data-bs-dismiss="modal"
                          aria-label="Close"
                        >
                          <img
                            src="./RightSectionIcons/close-small.png"
                            alt=""
                          />
                        </button>
                      </div>
                      <div class="modal-body px-0">
                        <div className="search-container d-flex align-items-center ps-3">
                          <img
                            src="./RightSectionIcons/search.png"
                            width="11.5px"
                            height="11.5px"
                            alt=""
                          />
                          <input
                            class="form-control  search-input "
                            type="search"
                            placeholder="Search token name or contract address"
                            aria-label="Search"
                            ref={baseInputRef}
                          />
                        </div>
                        <div className="horiziontal-btn-scroll-container mt-3">
                        <button onClick={()=>allTokenListModal()} className={selectedCat === null ? "btn btn-active" : "btn mx-2"}>ALL</button>
                        {loopCurrencyCatList()}

                        </div>
                      </div>
                      <div className="tokens-container">

                        {displayList}


                      </div>
                    </div>
                  </div>
                </div>

                <input
                  type="number"
                  class="form-control text-end p-3"
                  aria-label="Server"
                  placeholder="0"
                />
              </div>
            </div>
            <div className="rate-container d-flex justify-content-center my-4 ">
              <div className="rate pe-2">1 BUSD = 1.0005 USDC</div>
              <img src="./RightSectionIcons/rate.png" alt="" />
            </div>
            <div class="input-group mb-3 sa-text_box">
  <input type="text" class="form-control" placeholder="Recipient's address"  />
</div>
            <div className="confirm-btn-text">
              <button className="btn">Confirm Order</button>
              {/* <div className="text text-center py-2">
                Enter an amount to see more trading details
              </div> */}
            </div>
            <div className="divider-horizontal"></div>
            <div className="bottom  d-flex justify-content-between">
              <div className="left text-start">
                {/* <div className="p">Exchange Route</div> */}
                <div className="p">Reference price</div>
                <div className="p">Fee</div>
                <div className="p">Estimated amount </div>
                <div className="p">Maximum</div>
              </div>
              <div className="right text-white text-end">
                {/* <div className="p">SWFT</div> */}
                <div className="p">1 BNB = 453.023050 USDT</div>
                <div className="p">0.20% + 1 USDT</div>
                <div className="p"> 101.630560 </div>
                <div className="p"> 43.98641 BNB</div>
              </div>
            </div>

            {/* <div className="trade-reward d-flex justify-content-between mt-4">
              <div className="trade d-flex align-items-center ">
                <div className="text me-2">Trade Mining</div>
                <img src="./RightSectionIcons/quetionmark.png" alt="" />
              </div>
              <div className="reward d-flex ">
                <div className="max-reward">Max Reward 5.04 DEX</div>
                <div className="dollar ms-2 ">$16.68</div>
              </div>
            </div> */}
          </div>
        </div>

      </div>
    </div>
  );
};

export default Calculator;
